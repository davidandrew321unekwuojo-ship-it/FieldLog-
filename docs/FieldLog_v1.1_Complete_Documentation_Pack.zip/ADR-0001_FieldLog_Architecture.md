# ADR-0001: Layered, Offline-First Architecture for FieldLog v1

-   **Status:** Proposed for implementation
-   **Version:** 1.1
-   **Date:** 2026-11-17
-   **Applies to:** FieldLog v1
-   **Source of truth:** `requirements.md`, FieldLog v1.1 Product and
    Technical Implementation Specification
-   **Related:** Oracle of Chayil Reusable Infrastructure Engineering
    Principle

## 1. Context

FieldLog v1 is a standalone, offline-first agricultural field-record
application for farmers and agricultural researchers. It runs on Android
and desktop/laptop browsers, uses English, stores data locally in
IndexedDB, and supports manual JSON backup and restoration. Continuous
internet access, a backend server and automatic synchronization are not
required for ordinary v1 record management.

FieldLog is also the first product and engineering proving ground for
Oracle of Chayil's long-term infrastructure strategy. Its architecture
should encourage modular, well-tested components that may later support
other Oracle of Chayil applications, without adding scope or complexity
to v1.

### 1.1 Verified v1 constraints

The following have been checked against the approved v1.1 requirements:

-   Android phones and desktop/laptop browsers.
-   English interface.
-   Responsive web application / PWA.
-   Offline-first operation after initial successful loading and
    caching.
-   IndexedDB local storage.
-   Manual JSON export/import between devices.
-   No automatic synchronization, multi-user collaboration, cloud
    accounts, user authentication or backend dependency in v1.
-   Service worker caches application assets; it does not synchronize
    user data.

## 2. Architecture decision

FieldLog uses a modular client-side architecture. The detailed layers
below refine the six logical layers in the product specification; they
do not change the product's approved scope.

### 2.1 Mapping to the product specification

  -----------------------------------------------------------------------
  Product specification layer         Detailed implementation
  ----------------------------------- -----------------------------------
  Presentation                        `js/ui/`

  Application logic                   `js/services/` and `js/domain/`

  Data access                         `js/repositories/`

  Local database                      `js/infrastructure/database/`

  Offline application                 `service-worker.js`,
                                      `manifest.json`, application shell

  Backup and recovery                 `js/infrastructure/backup/`
  -----------------------------------------------------------------------

`js/shared/` contains domain-free utilities used by the application
layers. It is a supporting cross-cutting layer, not an additional
product feature.

### 2.2 Detailed layers

  -----------------------------------------------------------------------
  Layer                   Location                Responsibility
  ----------------------- ----------------------- -----------------------
  Domain                  `js/domain/`            Agricultural concepts
                                                  (site, plot, crop,
                                                  record) and
                                                  domain-specific rules
                                                  explicitly established
                                                  by requirements

  Services                `js/services/`          Application operations
                                                  and use cases

  Repositories            `js/repositories/`      Domain-aware
                                                  persistence interfaces
                                                  built on generic
                                                  storage

  Infrastructure          `js/infrastructure/`    Generic database
                                                  access, backup/recovery
                                                  and error handling

  Shared                  `js/shared/`            Generic, domain-free
                                                  helpers such as
                                                  validation primitives
                                                  and identifiers

  UI                      `js/ui/`                Screens, forms,
                                                  navigation and
                                                  rendering
  -----------------------------------------------------------------------

### 2.3 Dependency direction

``` text
UI → Services → Domain
Services → Repositories → Infrastructure

Infrastructure must not depend on Domain, Services, Repositories or UI.
Shared must not depend on any other application layer.
```

Services use repository interfaces and do not access IndexedDB directly.
Repositories use the generic database interface. The application
supplies the agricultural schema and repository configuration.

### 2.4 Rules

1.  **Generic infrastructure:** database, backup and error-handling
    modules contain no agricultural business rules.
2.  **Domain knowledge stays in the domain:** agricultural entities and
    only requirement-supported agricultural validation rules live in
    `domain/`. Generic validation handles general data checks without
    knowing what a farm, crop or plot means.
3.  **Repository abstraction:** services use repositories, not IndexedDB
    directly. Repositories can be replaced with fakes in service tests.
4.  **Schema ownership:** the database wrapper is generic. The FieldLog
    application supplies its schema and store configuration.
5.  **Incremental creation:** create modules when their functionality is
    needed; do not create empty files or abstractions merely to fill the
    proposed tree.
6.  **No premature infrastructure:** no networking, synchronization,
    cloud services or distributed infrastructure in v1.
7.  **No premature Oracle Core extraction:** candidates remain in
    FieldLog until implemented, tested and proven useful.

## 3. Approved v1 data model

The database has four principal object stores. The following fields are
taken from the approved product specification.

### 3.1 Sites

-   `id`
-   `name`
-   `type` --- Farm, Research site, or Other agricultural site
-   `description`
-   `createdAt`
-   `updatedAt`

### 3.2 Plots

-   `id`
-   `siteId`
-   `name`
-   `description`
-   `createdAt`
-   `updatedAt`

Each plot belongs to a site.

### 3.3 Crops

-   `id`
-   `name`
-   `variety`
-   `createdAt`
-   `updatedAt`

### 3.4 Records

-   `id`
-   `siteId`
-   `plotId` (optional)
-   `cropId` (optional)
-   `title`
-   `category`
-   `activityDate`
-   `description`
-   `measurements` (optional)
-   `createdAt`
-   `updatedAt`

Records belong to a site and may optionally refer to a plot and crop.
All entities have unique identifiers. The database is schema-versioned.

### 3.5 Crop-to-plot relationship interpretation

The requirements say crops can be associated with plots and field
records, but the proposed Plot and Crop field lists do not specify a
direct relationship field or a separate association store.

For v1, the least-complex interpretation is that a crop's association
with a plot is represented by a FieldLog record containing both `plotId`
and `cropId`. No permanent `cropId` field is added to Plots, and no
extra association store is introduced in v1. This allows the same crop
type to appear in records for different plots and over time.

If product discovery later establishes a need for a separately managed
crop-to-plot relationship independent of field records, that change
requires a new decision and schema migration. It is not silently added
to v1.

## 4. Project structure

The original requirements document supplied a proposed structure with
`database/`, `services/`, `ui/` and `utils/`. This ADR refines it to
make domain logic, repositories and generic infrastructure boundaries
explicit. The refinement is intentional and does not add product
features.

``` text
fieldlog/
├── index.html
├── manifest.json
├── service-worker.js
├── assets/
│   ├── icons/
│   └── images/
├── css/
│   ├── main.css
│   ├── layout.css
│   └── components.css
├── js/
│   ├── app.js
│   ├── domain/
│   │   ├── site.js
│   │   ├── plot.js
│   │   ├── crop.js
│   │   ├── record.js
│   │   └── validation/
│   ├── services/
│   ├── repositories/
│   ├── infrastructure/
│   │   ├── database/
│   │   ├── backup/
│   │   └── errors/
│   ├── shared/
│   │   ├── validation/
│   │   └── identifiers.js
│   └── ui/
├── tests/
└── docs/
    ├── requirements.md
    ├── architecture.md
    ├── testing.md
    └── oracle-core-candidates.md
```

Create files incrementally. This is a target organization, not a
requirement to create every file before it is needed.

## 5. Storage decision: IndexedDB

IndexedDB is the initial local storage choice for v1.

Reasons: - Built into browsers; no additional runtime database
dependency. - Works offline. - Supports structured records and
indexes. - Asynchronous, reducing the risk of blocking the interface
with database operations.

Trade-offs: - Browser storage can be cleared or evicted and is not a
guaranteed backup. - The application must provide JSON backup and
restoration. - Quota errors and persistent-storage availability must be
handled and tested.

Alternatives: - `localStorage`: synchronous and less suitable for
structured records. - SQLite compiled to WebAssembly: potentially useful
but adds weight and dependencies for this v1. - Cloud/server database:
excluded from v1.

## 6. Backup and recovery decisions

### 6.1 Backup coverage

A FieldLog workspace backup contains all four principal stores:

1.  Sites
2.  Plots
3.  Crops
4.  Records

This is a complete workspace backup, not a records-only export.
Restoring records without the sites, plots and crops they reference
could produce an unusable or incomplete workspace.

### 6.2 Backup format

The versioned JSON backup contains: - A format identifier. - A backup
format version. - An export timestamp. - The application version. - Data
sections for all four stores. - An integrity checksum.

The checksum detects accidental corruption; it does not establish
semantic correctness. Import must validate format, version, structure,
identifiers and relationships before changing existing data.

### 6.3 Import semantics: replace

For v1, import is a **complete workspace restore using replace
semantics**:

-   The user is clearly told that the current FieldLog workspace will be
    replaced.
-   The user must explicitly confirm before restoration begins.
-   The incoming backup must contain all required store sections and
    pass validation.
-   A successful restore replaces the contents of all four FieldLog
    stores with the validated backup contents.
-   A failed validation or restoration leaves the existing logical
    database state unchanged.
-   Merge is not supported in v1. It may be considered in a later
    version with separately specified conflict rules.

This decision is chosen because v1 supports manual backup/restore, not
multi-device collaboration or synchronization. Replace semantics are
simpler and predictable for restoring a workspace. The explicit
confirmation and atomicity requirements protect against accidental data
loss.

### 6.4 Atomic restoration

All writes for one import must be all-or-nothing. Use one IndexedDB
transaction spanning every affected store, or an equivalent
staged-and-committed approach that guarantees the same outcome.

If validation or restoration fails, the complete logical database state
(all stores, keys, values and schema version) must equal the state
before import. Verify this with complete logical snapshots, not spot
checks.

No writes occur before validation has completed.

## 7. Offline behaviour

-   The service worker caches the application's own required assets.
-   IndexedDB stores user data independently of the application cache.
-   The service worker does not synchronize records or communicate with
    a backend.
-   After a successful initial online load and caching, the application
    must reopen and support core record operations offline.
-   Application updates must not delete or reset the user's IndexedDB
    data.

## 8. Oracle Core candidates

Potential candidates, not existing Oracle Core modules:

-   Generic database wrapper.
-   Generic backup and recovery.
-   Generic error handling.
-   Generic validator.
-   Identifier utilities.

Track candidates in `docs/oracle-core-candidates.md`. Extract only after
implementation, automated tests (including failure paths), relevant
real-device verification and demonstrated reuse. Do not create an Oracle
Core package or folder in FieldLog v1.

## 9. Consequences

**Positive** - Clear boundaries support testing and future reuse. -
Agricultural rules do not leak into generic infrastructure. - The
storage implementation can potentially be replaced behind
repositories. - Complete backup and atomic restoration protect workspace
integrity. - The architecture remains within the approved offline-first
scope.

**Costs** - More modules and indirection than a single-layer
application. - Architecture checks and repository interfaces require
maintenance. - Replace-only import means users cannot combine two
workspaces in v1.

## 10. Open decisions and implementation constraints

  -----------------------------------------------------------------------
  Item                                Status / action
  ----------------------------------- -----------------------------------
  Import replace vs merge             **Resolved:** replace-only for v1;
                                      explicit confirmation and atomic
                                      restore required

  Backup coverage                     **Resolved:** all four stores

  Crop-to-plot association            **Resolved for v1:** represented
                                      through records containing `plotId`
                                      and `cropId`; no extra store

  JavaScript module system            **Resolved:** native browser ES
                                      modules; use `type="module"` for
                                      the application entry point

  Browser support                     Initial verification target:
                                      current stable Chrome on Android
                                      and current stable Chrome on
                                      desktop. Other browsers are not
                                      promised until tested and
                                      documented

  Persistent storage and quota        Investigate
                                      `navigator.storage.persist()` where
                                      available; handle
                                      denial/unavailability and quota
                                      errors; do not claim guaranteed
                                      persistence

  Backup reminders                    Product behaviour not specified; do
                                      not add scheduled reminders in the
                                      first implementation without a
                                      separate product decision

  Backup format compatibility         Version 1 format is required;
                                      older-version migration policy is
                                      decided when a later format exists

  Domain validation rules             Use only rules explicitly supported
                                      by requirements. Do not invent
                                      numeric/date limits or unspecified
                                      required fields

  Test framework                      Select a lightweight
                                      framework/tooling during
                                      implementation preparation; it must
                                      not become a runtime dependency of
                                      the deployed PWA

  Dependent-record deletion           **Open:** define safe behaviour
                                      before implementing deletion of a
                                      site with plots/records or a
                                      plot/crop with dependent records
  -----------------------------------------------------------------------

## 11. Architecture enforcement

An automated architecture check must use a real parser or project
tooling to extract dependencies, resolve canonical paths and inspect the
transitive dependency graph.

It must cover the dependency mechanisms actually used by the project: -
Static, side-effect and re-export ES module imports. - Literal dynamic
imports. - Non-literal dynamic imports flagged for explicit review. -
`importScripts()` if used in the service worker. - Script tags in
HTML. - Workers or CommonJS only if introduced by project tooling.

Forbidden dependencies must fail the check. Shared globals that bypass
imports must either be prohibited across layers or separately checked.

## 12. Status

This ADR is **Proposed for implementation**. It records the
architectural direction and resolves the initial backup, import,
crop/plot relationship and module-system choices. It does not authorize
implementation of unresolved dependent-record deletion behaviour or
unapproved features.

Review this ADR when a material architecture decision changes.
