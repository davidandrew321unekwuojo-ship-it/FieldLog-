# ORACLE OF CHAYIL

# FIELDLOG --- FINALIZED PRODUCT AND TECHNICAL IMPLEMENTATION SPECIFICATION

**Document:** Product Requirements and Technical Architecture\
**Version:** 1.1\
**Status:** Approved initial direction; implementation pending\
**Product:** FieldLog\
**Parent company:** Oracle of Chayil

------------------------------------------------------------------------

## PART A --- PRODUCT DEFINITION

### 1. Product definition

FieldLog is an offline-first agricultural field-record management
application for farmers and agricultural researchers.

It enables users to record, organize, review and preserve information
about farms, research sites, plots, crops, farming activities,
observations and measurements.

The application will work on Android phones and computers, without
requiring continuous internet access.

Its first release will use local device storage. Future versions will
introduce local networking, multi-device synchronization and reusable
infrastructure through Oracle Core.

### 2. Product objectives

FieldLog v1 must:

1.  Allow users to manage farms and research sites.
2.  Allow users to organize plots and crops.
3.  Allow users to create, view, edit and delete agricultural records.
4.  Support different categories of agricultural activities and
    observations.
5.  Store information locally on the device.
6.  Remain usable without an internet connection after initial
    installation and caching.
7.  Support searching and filtering.
8.  Allow information to be exported and restored.
9.  Work across Android phones and desktop computers.
10. Establish a maintainable foundation for future Oracle Core
    components.

### 3. Target users

**Farmers and farm owners**

FieldLog should help them record:

-   Crops planted.
-   Planting dates.
-   Irrigation activities.
-   Fertilizer applications.
-   Pest and disease observations.
-   Harvesting activities.
-   General farm activities.

**Agricultural researchers and field officers**

FieldLog should help them record:

-   Research sites.
-   Experimental plots.
-   Field observations.
-   Measurements and units.
-   Research activities.
-   Observation dates.
-   Historical field information.

Both groups will initially use the same application and data model.

### 4. Confirmed platform decisions

  Decision               Approved direction
  ---------------------- ----------------------------------------
  Mobile support         Android
  Computer support       Desktop and laptop browsers
  Interface language     English
  Connectivity           Offline-first
  Application format     Responsive web application / PWA
  Initial storage        IndexedDB
  Initial deployment     Browser-accessible application
  Initial architecture   Single-device, local-first application

**Important offline limitation**

Each installation will maintain its own local database.

If a user installs FieldLog on two different phones, their records will
not automatically appear on both devices.

For v1, users can transfer information manually using backup and
restore.

Automatic synchronization belongs to a later release.

------------------------------------------------------------------------

## PART B --- VERSION 1 SCOPE

### 5. Features included in v1

#### 5.1 Farm and research-site management

Users can:

-   Create a farm or research site.
-   Name the location.
-   Add a description.
-   Edit site details.
-   View associated plots.
-   Delete a site after appropriate confirmation.

A site will have a type:

-   Farm.
-   Research site.
-   Other agricultural site.

#### 5.2 Plot management

Users can:

-   Create plots under a site.
-   Give each plot a name or identifier.
-   Add a description.
-   Edit plot details.
-   View records associated with the plot.

#### 5.3 Crop management

Users can:

-   Register crops.
-   Record crop names.
-   Record crop varieties where known.
-   Associate crops with plots and field records.

#### 5.4 Agricultural records

Each record will support:

-   Record title.
-   Record category.
-   Farm or research site.
-   Plot, where applicable.
-   Crop, where applicable.
-   Activity or observation date.
-   Description.
-   Optional measurements.
-   Measurement units.
-   Creation timestamp.
-   Last-modified timestamp.

Initial categories:

1.  Planting.
2.  Irrigation.
3.  Fertilizer application.
4.  Pest observation.
5.  Disease observation.
6.  Weather observation.
7.  Harvesting.
8.  Research observation.
9.  General field activity.

#### 5.5 Record management

Users can:

-   Create records.
-   View records.
-   Edit records.
-   Delete records after confirmation.
-   View records in chronological order.
-   Search by title and description.
-   Filter by category, crop, site and plot.

#### 5.6 Backup and recovery

Users can:

-   Export their records as a JSON backup.
-   Import a previously exported backup.
-   Validate backup contents before importing.
-   Detect duplicate record identifiers.
-   Review import results.
-   Restore previously exported information.

#### 5.7 Offline application support

FieldLog will use a service worker to cache its application files.

After successful initial installation and caching, users should be able
to reopen the application without internet access.

IndexedDB will hold their records independently of the application
cache.

### 6. Features explicitly excluded from v1

The following are not part of the first release:

-   Automatic synchronization between devices.
-   Multi-user collaboration.
-   Cloud accounts.
-   User authentication.
-   Real-time collaboration.
-   AI crop diagnosis.
-   AI yield prediction.
-   Satellite monitoring.
-   GPS-based farm mapping.
-   Weather-service integration.
-   Sensor integration.
-   Automated agricultural recommendations.
-   Payments and financial management.

These features may be considered after validating the initial product.

------------------------------------------------------------------------

## PART C --- TECHNICAL ARCHITECTURE

### 7. Architecture decision

FieldLog v1 will use a modular client-side architecture.

The application will run directly in the user's browser or installed
PWA.

It will not require a backend server for ordinary record management.

**Architecture layers**

1.  Presentation layer.
2.  Application logic layer.
3.  Data access layer.
4.  Local database layer.
5.  Offline application layer.
6.  Backup and recovery layer.

### 8. Proposed architecture diagram

``` text
                 FIELDLOG V1
                      |
             PRESENTATION LAYER
          HTML + CSS + JavaScript
                      |
             APPLICATION LAYER
       -------------------------------
       |             |               |
   Site Manager  Record Manager  Crop Manager
       |             |               |
       -------------------------------
                      |
               DATA ACCESS LAYER
                Database Service
                      |
                 INDEXEDDB
              Local Device Storage
                      |
          -------------------------
          |                       |
     BACKUP SERVICE          OFFLINE SERVICE
     JSON Export/Import      Service Worker
          |                       |
          -------------------------
                      |
              USER'S DEVICE
          Android / Computer
```

### 9. Technology stack

  Component           Technology       Responsibility
  ------------------- ---------------- --------------------------------
  Interface           HTML             Application structure
  Styling             CSS              Responsive presentation
  Application logic   JavaScript       Application behaviour
  Local database      IndexedDB        Persistent structured records
  Offline support     Service Worker   Application asset caching
  Installability      PWA manifest     Application installation
  Backup              JSON             Data export and restoration
  Version control     Git              Source-code history
  Repository          GitHub           Code storage and collaboration

**Technology selection rationale**

**HTML, CSS and JavaScript**

These are established web technologies that we can develop using our
existing skills.

**IndexedDB**

Provides asynchronous, structured local browser storage. It is more
suitable than localStorage for our growing record-management
requirements.

**Service Worker**

Allows the application shell to be cached and made available offline
after initial loading.

**JSON**

Provides a portable format for exporting and restoring information.

We will not introduce Node.js, PouchDB or CouchDB into v1 because their
primary benefits belong to our later networking and synchronization
stages.

------------------------------------------------------------------------

## PART D --- DATA MODEL

### 10. Initial database structure

The database will initially contain four principal object stores.

#### 10.1 Sites

Represents farms and research locations.

Suggested fields:

-   id
-   name
-   type
-   description
-   createdAt
-   updatedAt

#### 10.2 Plots

Represents sections within a site.

Suggested fields:

-   id
-   siteId
-   name
-   description
-   createdAt
-   updatedAt

#### 10.3 Crops

Represents registered crops.

Suggested fields:

-   id
-   name
-   variety
-   createdAt
-   updatedAt

#### 10.4 Records

Represents agricultural activities and observations.

Suggested fields:

-   id
-   siteId
-   plotId
-   cropId
-   title
-   category
-   activityDate
-   description
-   measurements
-   createdAt
-   updatedAt

Optional relationships such as plotId and cropId must support records
where a plot or crop is not applicable.

All records must have unique identifiers.

The database must support schema versioning so future upgrades can add
or modify fields without unnecessarily losing existing records.

------------------------------------------------------------------------

## PART E --- CODE ORGANIZATION

### 11. Proposed project structure

``` text
fieldlog/
│
├── index.html
├── manifest.json
├── service-worker.js
│
├── assets/
│   ├── icons/
│   └── images/
│
├── css/
│   ├── main.css
│   ├── layout.css
│   └── components.css
│
├── js/
│   ├── app.js
│   │
│   ├── database/
│   │   ├── db.js
│   │   └── schema.js
│   │
│   ├── services/
│   │   ├── site-service.js
│   │   ├── plot-service.js
│   │   ├── crop-service.js
│   │   ├── record-service.js
│   │   └── backup-service.js
│   │
│   ├── ui/
│   │   ├── navigation.js
│   │   ├── forms.js
│   │   └── rendering.js
│   │
│   └── utils/
│       ├── validation.js
│       └── identifiers.js
│
├── tests/
│
└── docs/
    ├── requirements.md
    ├── architecture.md
    └── testing.md
```

This is the proposed structure. We can adjust it as the implementation
develops.

The objective is to separate database operations, application logic and
user-interface behaviour.

------------------------------------------------------------------------

## PART F --- IMPLEMENTATION PLAN

### 12. Development phases

#### Phase 0: Engineering preparation

Tasks:

-   Establish the GitHub repository.
-   Create the project structure.
-   Record product requirements.
-   Document architecture decisions.
-   Define initial testing procedures.
-   Prepare the development environment.

**Deliverable:** A prepared and documented development workspace.

**Exit condition:** The project structure and initial technical
decisions are ready for implementation.

#### Phase 1: Application foundation

Tasks:

-   Create the HTML application structure.
-   Develop the navigation.
-   Implement responsive layouts.
-   Create the initial dashboard.
-   Create forms for site and record management.
-   Establish consistent interface components.

**Deliverable:** A navigable FieldLog interface.

**Exit condition:** The main application screens work on Android and
desktop-sized displays.

#### Phase 2: Local database

Tasks:

-   Initialize IndexedDB.
-   Create database object stores.
-   Implement database operations.
-   Implement site management.
-   Implement plot management.
-   Implement crop management.
-   Implement record management.
-   Add validation and error handling.

**Deliverable:** A functional local record-management application.

**Exit condition:** Users can create, retrieve, update and delete
information, and records persist after normal application restarts.

#### Phase 3: Search and usability

Tasks:

-   Implement record search.
-   Implement filtering.
-   Add chronological sorting.
-   Improve form validation.
-   Provide clear success and error messages.
-   Test common user workflows.

**Deliverable:** FieldLog with usable record discovery and management.

**Exit condition:** Users can efficiently retrieve and manage their
agricultural information.

#### Phase 4: Backup and recovery

Tasks:

-   Implement JSON export.
-   Implement JSON import.
-   Add backup format versioning.
-   Validate imported records.
-   Detect duplicate identifiers.
-   Test restoration.
-   Test malformed backup files.

**Deliverable:** A tested backup and restoration system.

**Exit condition:** Exported data can be restored successfully without
unintended duplication or silent corruption.

#### Phase 5: Offline application support

Tasks:

-   Create the PWA manifest.
-   Implement the service worker.
-   Cache essential application resources.
-   Test offline reopening.
-   Test application updates.
-   Verify that cached application files and database records remain
    separate.

**Deliverable:** Installable FieldLog PWA with offline availability.

**Exit condition:** The application can reopen and manage existing
records after the device has disconnected from the internet.

#### Phase 6: Release validation

Tasks:

-   Test on Android browsers.
-   Test on desktop browsers.
-   Test database persistence.
-   Test backup and restoration.
-   Test offline operation.
-   Test application updates.
-   Fix critical defects.
-   Document known limitations.

**Deliverable:** FieldLog v1 candidate.

**Exit condition:** All mandatory acceptance tests pass.

------------------------------------------------------------------------

## PART G --- ACCEPTANCE TESTING

### 13. Mandatory tests

  Test                    Expected result
  ----------------------- ---------------------------------------------
  Create a farm           Farm is saved
  Create a plot           Plot is associated with the correct site
  Register a crop         Crop is saved
  Create a field record   Record is saved
  Edit a record           Updated information persists
  Delete a record         Record is removed as intended
  Restart application     Existing records remain
  Search records          Relevant records are returned
  Export backup           Valid JSON file is generated
  Import backup           Valid records are restored
  Invalid import          Import is rejected safely
  Disconnect internet     Core application functions continue working
  Reopen offline          Cached application loads
  Open on desktop         Interface remains usable
  Open on Android         Interface remains usable

Testing must include realistic failure conditions, not just successful
demonstrations.

### 14. Data protection limitations

IndexedDB is local browser storage, not a guaranteed backup service.

Users may lose data if:

-   They uninstall or clear the browser's data.
-   The device is damaged or lost.
-   Browser storage is evicted.
-   The database becomes corrupted.

Therefore:

-   We must provide clear backup instructions.
-   Users must be encouraged to export backups regularly.
-   We must never claim that local storage alone guarantees permanent
    preservation.
-   Sensitive data protection must be evaluated before wider
    institutional deployment.

------------------------------------------------------------------------

## PART H --- FUTURE INFRASTRUCTURE

### 15. Relationship with Oracle Core

FieldLog will initially contain its own modular implementation.

As we develop and validate the product, we will identify which
components are suitable for reuse.

Potential future Oracle Core modules:

1.  Data Engine.
2.  Backup and Recovery.
3.  Network Layer.
4.  Synchronization Engine.
5.  Identity and Access System.
6.  Security Layer.
7.  API and Integration Layer.
8.  Monitoring and Diagnostics.

We should extract these components only when their interfaces,
responsibilities and reliability requirements are sufficiently
understood.

### 16. Future development direction

After FieldLog v1:

-   Introduce a local Node.js server.
-   Enable access over local Wi-Fi.
-   Allow multiple devices to communicate.
-   Develop synchronization and conflict handling.
-   Introduce device identity and authentication.
-   Extract reusable Oracle Core packages.
-   Validate the infrastructure through additional applications.

These are future objectives, not v1 capabilities.

------------------------------------------------------------------------

## PART I --- GOVERNANCE

### 17. Engineering rules

1.  Every feature must have a defined purpose.
2.  Every milestone must have an acceptance test.
3.  No milestone is complete without evidence.
4.  Code changes must be tracked through Git.
5.  Working versions must be preserved.
6.  Security and data integrity must not be treated as optional.
7.  New technologies must solve identified problems.
8.  The product must be validated with actual users.
9.  We must document limitations honestly.
10. The product roadmap must remain aligned with Oracle of Chayil's
    infrastructure strategy.

### 18. Immediate execution milestone

**Current status:** Product definition and initial architecture
established.

**Next milestone:** Prepare the FieldLog development environment and
create the initial application foundation.

Before coding, we must confirm the repository structure and the
development environment available to the team.

------------------------------------------------------------------------

**ORACLE OF CHAYIL**

Building reliable digital infrastructure through disciplined
engineering.

**FieldLog v1 --- Product and Technical Specification**

------------------------------------------------------------------------

# Oracle of Chayil --- Reusable Infrastructure Engineering Principle

FieldLog is the first product and engineering proving ground for Oracle
of Chayil's long-term infrastructure strategy.

Although FieldLog v1 must remain a simple, standalone, offline-first
agricultural field-record application, its architecture should encourage
the development of reusable, modular and well-tested software
components.

**Engineering requirements:**

1.  Keep business-specific agricultural logic separate from
    general-purpose data management capabilities.
2.  Use clear interfaces between the user interface, application
    services and data layer.
3.  Avoid unnecessary dependencies and tightly coupled components.
4.  Document important architectural decisions.
5.  Design data validation, backup, recovery and error handling with
    future reuse in mind.
6.  Write tests for foundational components.
7.  Do not introduce networking, synchronization, cloud services or
    distributed infrastructure prematurely.
8.  Do not extract components into Oracle Core until they have been
    implemented, tested and proven useful.
9.  Preserve FieldLog v1's approved scope and offline-first
    requirements.

**Long-term objective:**

Develop proven, reusable infrastructure components that can support
multiple Oracle of Chayil applications and eventually operate as an
independent technology foundation.
