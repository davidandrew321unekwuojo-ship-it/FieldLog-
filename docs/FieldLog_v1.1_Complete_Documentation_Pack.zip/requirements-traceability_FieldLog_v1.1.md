# FieldLog v1.1 Requirements Traceability Matrix

-   **Status:** Initial cross-check completed
-   **Date:** 2026-11-17
-   **Source:** FieldLog v1.1 Product and Technical Implementation
    Specification
-   **Related:** ADR-0001 and `testing.md`

This matrix links approved product requirements to their architecture
treatment and verification.

  ------------------------------------------------------------------------------------------
  Requirement               Architecture         Test coverage             Status
                            treatment                                      
  ------------------------- -------------------- ------------------------- -----------------
  Android and               Responsive           Physical Android and      Aligned
  desktop/laptop browsers   client-side PWA      desktop verification      

  English interface         UI presentation      English UI checks         Aligned
                            responsibility                                 

  Offline-first after       Service worker       Offline reopen and        Aligned
  initial caching           caches application   offline CRUD              
                            assets; IndexedDB                              
                            stores records                                 

  No backend needed for     Client-side          Offline workflow and      Aligned
  core v1 record management architecture         no-backend dependency     
                                                 checks                    

  Manage farms/research     Site domain entity   Site                      Aligned
  sites                     and                  create/view/edit/delete   
                            service/repository   confirmation              

  Manage plots              Plot domain entity   Plot CRUD scope as        Aligned
                            linked to site       specified; relationship   
                                                 tests                     

  Manage crops and          Crop domain entity   Crop registration,        Aligned
  varieties                                      variety and record        
                                                 association               

  Associate crops with      In v1, record        Record relationship tests Architecture
  plots and records         carries both                                   interpretation
                            optional `plotId`                              
                            and `cropId`                                   

  Create/view/edit/delete   Record entity and    Record lifecycle tests    Aligned
  records                   service                                        

  Nine initial record       Domain category set  Test each category        Aligned
  categories                                                               

  Chronological ordering    Service/query and UI Chronological ordering    Aligned
                            presentation         tests                     

  Search title and          Search/query         Separate title and        Aligned
  description               functionality        description tests         

  Filter by category, crop, Query/filter         Individual and combined   Aligned
  site and plot             functionality        filter tests              

  JSON export/import        Generic backup       Full-workspace            Aligned
                            infrastructure with  export/restore tests      
                            FieldLog data                                  
                            sections                                       

  Validate imports and      Backup validation    Malformed, duplicate and  Aligned
  detect duplicate          before writes        relationship failure      
  identifiers                                    tests                     

  Manual transfer between   JSON file transfer;  Android-to-desktop and    Aligned
  devices                   no sync              desktop-to-Android        
                                                 transfer tests            

  Four principal data       Sites, Plots, Crops, Multi-store persistence   Aligned
  stores                    Records              and backup tests          

  Unique IDs and schema     Generic storage and  Duplicate-key and         Aligned
  versioning                identifier utilities schema-upgrade tests      

  Service worker caches app Offline              Verify no data sync and   Aligned
  files only                infrastructure       app update behaviour      

  Local storage is not      Documented storage   Quota, persistence and    Aligned
  guaranteed backup         limitation           backup guidance checks    

  No automatic sync, cloud  Explicit v1          Scope review at release   Aligned
  accounts, AI diagnosis,   exclusions           gate                      
  GPS, weather integration,                                                
  sensors, payments                                                        

  Future Oracle Core reuse  Candidates tracked;  Core eligibility criteria Aligned
                            extraction only                                
                            after proof                                    
  ------------------------------------------------------------------------------------------

## Decisions recorded during cross-check

1.  **Backup coverage:** a backup includes all four stores (Sites,
    Plots, Crops, Records), because the product describes a workspace
    and records refer to the other entities.
2.  **Import semantics:** v1 uses replace-only full-workspace
    restoration. The UI must warn and require confirmation. Merge is
    deferred.
3.  **Crop-to-plot association:** v1 represents this through a record
    containing both `plotId` and `cropId`; no extra field or association
    store is introduced.
4.  **Module system:** use native browser ES modules.
5.  **Initial browser verification:** current stable Chrome on Android
    and current stable Chrome on desktop. Other browsers are not claimed
    as supported until tested.
6.  **Dependent-record deletion:** remains open. Do not implement
    destructive cascading behaviour until an explicit policy is
    approved.
7.  **Validation limits:** no unspecified date limits, measurement
    ranges or extra mandatory fields may be invented.

## Remaining release gate

Before release, execute the tests, record results and verify the
application on the target physical devices. This matrix documents
coverage design; it is not evidence that implementation or tests have
already passed.
