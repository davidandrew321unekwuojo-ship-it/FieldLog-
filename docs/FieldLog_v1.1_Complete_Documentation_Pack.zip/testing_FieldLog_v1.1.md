# FieldLog v1 Foundational and Requirements Test Plan

-   **Status:** Draft for implementation
-   **Version:** 1.1
-   **Date:** 2026-11-17
-   **Source of truth:** FieldLog v1.1 Product and Technical
    Implementation Specification
-   **Related:** ADR-0001, Layered Offline-First Architecture

## 1. Purpose and principles

This plan defines how FieldLog v1 requirements and foundational
architecture are verified.

Principles: - Every approved feature has one or more acceptance tests. -
Test each layer in isolation where practical. - Services are tested with
fake repositories; repositories with a test database. - Generic
infrastructure tests contain no agricultural business concepts. -
Failure paths are tested as thoroughly as success paths. - No networking
or synchronization tests are included because those features are
excluded from v1. - Do not invent agricultural validation rules. A test
rule must cite an approved requirement or a separately approved
decision. - Manual device tests are required where browser/device
behaviour cannot be established by unit tests alone.

## 2. Test environments

### 2.1 Initial browser targets

-   Current stable Chrome on a physical Android phone.
-   Current stable Chrome on a desktop or laptop computer.

These are the initial verification targets, not a claim that other
browsers cannot work. Any additional supported browser must be added to
the test matrix and verified.

### 2.2 Test data

Use synthetic test data. Include: - Empty workspace. - One site with
multiple plots. - Multiple crops. - Records with and without optional
plot/crop associations. - Records with and without optional
measurements. - Records across different dates and all nine approved
categories. - A multi-store workspace backup.

Do not use real farmers' or researchers' sensitive information in
automated test fixtures.

## 3. Requirements acceptance tests

### 3.1 Sites (`tests/domain/`, `tests/services/`, `tests/ui/`)

Verify: - Create a Farm site. - Create a Research site. - Create an
Other agricultural site. - Save the supplied name and description. -
View site details. - Edit site details and confirm persistence. - View
plots associated with the selected site. - Request deletion and show an
appropriate confirmation before deletion is performed. - Cancel deletion
and confirm the site remains unchanged. - Confirm deletion behaviour
when dependent plots or records exist only after that behaviour is
explicitly decided and documented.

### 3.2 Plots

Verify: - Create a plot under a selected site. - Persist the correct
`siteId`. - View and edit plot details. - Display the plot under the
correct site. - View records associated with the plot. - Reject or
safely handle a plot reference to a nonexistent site. - Plot deletion
behaviour remains unimplemented until dependent-record behaviour is
decided.

### 3.3 Crops

Verify: - Register a crop with a name. - Save a variety when supplied. -
Support a crop with no known variety. - View and edit crop details where
the implemented UI exposes editing. - Associate a crop with a field
record. - Verify the v1 crop-to-plot association through records
containing both `plotId` and `cropId`. - Do not require a separate
permanent crop-to-plot association store in v1.

### 3.4 Agricultural records

Verify create, view, edit and delete operations.

Each record supports: - Title. - Category. - Site. - Optional plot. -
Optional crop. - Activity/observation date. - Description. - Optional
measurements and units. - Creation timestamp. - Last-modified timestamp.

Verify: - Each of the nine approved categories can be selected and
saved: Planting, Irrigation, Fertilizer application, Pest observation,
Disease observation, Weather observation, Harvesting, Research
observation and General field activity. - A record with no plot is
supported. - A record with no crop is supported. - A record with both
plot and crop is supported. - The selected site, plot and crop
identifiers are preserved correctly. - Creation and modification
timestamps are populated and updated appropriately. - A record referring
to a nonexistent site, plot or crop is rejected safely. - Delete
requires confirmation; cancellation leaves the record unchanged.

Do not invent additional required fields, date limits, measurement
ranges or category values.

### 3.5 Chronological ordering, search and filters

Verify: - Records are displayed in chronological order using
`activityDate`. - Search by title. - Search by description. - Filter by
each category. - Filter by crop. - Filter by site. - Filter by plot. -
Combine supported filters and search criteria. - Empty results are
communicated clearly. - Clearing search and filters restores the
unfiltered list.

### 3.6 Responsive interface and language

Verify: - User-facing interface text is in English. - Main navigation is
usable on a small Android screen. - Forms and controls are usable with
touch. - Layout adapts to desktop/laptop dimensions. - Main navigation
and forms are usable with keyboard and mouse. - Long names and
descriptions do not make essential controls inaccessible. - Success,
validation and error messages are understandable and do not expose
internal stack traces or database details.

### 3.7 Backup and restoration

A FieldLog backup is a **complete workspace backup** containing all four
stores: Sites, Plots, Crops and Records.

Verify: - Export generates a valid JSON file. - Export includes format
identifier, backup format version, export timestamp, application
version, all four data sections and integrity checksum. - Empty
workspace can be exported and restored. - A populated
multi-site/multi-plot/multi-crop workspace can be exported and
restored. - Optional fields and relationships survive round-trip
restoration. - Export then import into an empty workspace reproduces the
original logical data. - Import results communicate success or failure
clearly. - Duplicate identifiers within the imported backup are
rejected. - Dangling site, plot or crop references are rejected. -
Unknown format identifier is rejected. - Unsupported backup version is
rejected with a clear message. - Truncated, malformed and non-JSON files
are rejected. - Checksum mismatch is rejected. - A valid checksum does
not bypass semantic validation. - A repeated import follows replace
semantics and does not create duplicate records. - Import clearly warns
that the existing workspace will be replaced and requires explicit
confirmation. - Cancelling the confirmation performs no writes and
leaves the workspace unchanged.

### 3.8 Import safety and atomic restoration

**Logical snapshot helper**

Create a test helper that captures the complete logical database
state: - Database name and schema version. - All object store names. -
For each store: key path, auto-increment setting and index
definitions. - Every key/value pair in every store, in deterministic key
order. - Deep comparison of values, including nested objects, arrays,
dates and null/undefined distinctions where supported.

**Failure procedure**

For every failure below: 1. Capture a complete snapshot. 2. Attempt
import. 3. Capture another complete snapshot. 4. Assert that both
snapshots are deeply equal. 5. Assert that the user receives a clear
failure message.

Failure cases: - Truncated, malformed or non-JSON backup. - Checksum
mismatch. - Valid checksum but invalid content. - Duplicate
identifiers. - Dangling relationships. - Unknown format or unsupported
version. - Missing required store section. - Failure injected on the
first, middle and last restoration write. - Quota-exceeded error. -
Transaction abort or database connection failure. - Existing non-empty
workspace with data in all four stores.

Atomicity requirements: - Validate the entire backup before the first
write. - No write occurs when validation fails. - Restoration is one
all-or-nothing operation across all affected stores, or an equivalent
staged commit with the same guarantee. - A mid-restore failure leaves
every store unchanged. - A successful import replaces the complete
workspace with the validated incoming workspace.

### 3.9 Offline and PWA behaviour

Verify: - First load and cache the application while online. - Reopen
the application in airplane mode. - View existing records offline. -
Create, edit and delete records offline. - Search and filter offline. -
Export a backup offline. - Import a valid backup offline. - Service
worker caches application assets only. - No user-data synchronization or
backend request is required for core record management. - Install the
PWA where supported by the target browser. - Launch the installed
application offline after successful caching. - Update application
assets and confirm IndexedDB records remain intact. - Clear or update
the application cache without intentionally deleting the database.

### 3.10 Device and manual backup transfer

On the physical Android device and desktop/laptop: - Verify layout and
primary workflows. - Export a backup on Android and manually transfer it
to the computer. - Import it on the computer and verify all four stores
and relationships. - Export a backup on the computer and manually
transfer it to Android. - Import it on Android and verify all four
stores and relationships. - Confirm the user understands that the
devices do not automatically synchronize.

### 3.11 Data protection and storage behaviour

Verify: - Browser storage quota errors are surfaced clearly. - Where
supported, the application can request persistent storage. - Denial or
unavailability of persistent storage does not crash the application. -
The interface explains that IndexedDB is local storage, not a guaranteed
backup. - Backup guidance is available. - Clearing browser data or
losing the device is documented as a data-loss risk. - No claim of
permanent preservation is made.

## 4. Foundational component tests

### 4.1 Generic validator (`tests/shared/`)

Verify: - Required-field checks where a schema explicitly marks a field
required. - Type checks. - Generic range and length checks only when
configured by a schema. - Boundary values for configured limits. -
Unknown/extra field handling is consistent. - Error output identifies
the failing field and reason. - Input is not mutated. - Generic
validator contains no FieldLog agricultural terms or rules.

### 4.2 Domain validation (`tests/domain/`)

Create a rule register. Each rule must cite the exact requirement or
approved decision.

  ----------------------------------------------------------------------------
  ID             Entity         Rule           Source         Status
  -------------- -------------- -------------- -------------- ----------------
  D-01           Site           Site type is   Requirements   Required
                                one of Farm,   §5.1           
                                Research site,                
                                Other                         
                                agricultural                  
                                site                          

  D-02           Plot           Plot belongs   Requirements   Required
                                to a site      §10.2          
                                through                       
                                `siteId`                      

  D-03           Record         Record belongs Requirements   Required
                                to a site      §10.4          
                                through                       
                                `siteId`                      

  D-04           Record         `plotId` and   Requirements   Required
                                `cropId` are   §10.4          
                                optional                      

  D-05           Record         Category is    Requirements   Required
                                one of the     §5.4           
                                nine initial                  
                                categories                    

  D-06           Entities       Identifiers    Requirements   Required
                                are unique     §10            

  D-07           Crop/Plot      Plot           ADR-0001 §3.5  Approved
                                association is                architecture
                                represented by                interpretation
                                a record                      
                                containing                    
                                both `plotId`                 
                                and `cropId`                  
                                in v1                         
  ----------------------------------------------------------------------------

For each rule, test valid and invalid cases. Do not add unspecified date
limits, numeric measurement ranges, mandatory descriptions or other
rules without approval.

### 4.3 Database wrapper (`tests/infrastructure/database/`)

Use a generic test schema without agricultural concepts.

Verify: - Create, read, update, delete and list. - Index queries. - Data
persists after closing and reopening. - Initial schema creation. -
Schema version upgrade. - Duplicate-key and missing-key behaviour. -
Invalid input handling. - Quota-exceeded and blocked-upgrade errors are
surfaced. - Complete logical snapshot helper is correct.

### 4.4 Repositories (`tests/repositories/`)

Verify: - Mapping between domain objects and stored values without data
loss. - Repositories use only the generic database interface. -
Application supplies schema and repository configuration. - Not-found
and storage-failure outcomes are defined. - Repository tests cover all
four stores.

### 4.5 Services (`tests/services/`)

Verify: - Each required application operation. - Validation occurs
before persistence. - Invalid data is never stored. - Repository
failures are handled and reported. - Site/plot/crop/record relationships
are preserved. - Deletion of entities with dependants is not implemented
until the deletion policy is approved.

### 4.6 Error handling (`tests/infrastructure/errors/`)

Verify: - Errors are normalized into a consistent structure. -
User-facing messages are clear and do not reveal internal details. -
Unexpected errors are caught and the application remains usable. -
Diagnostic information is useful for debugging without exposing
sensitive user data.

### 4.7 Architecture enforcement (`tests/architecture/`)

Verify the ADR dependency rules: - UI → Services → Domain. - Services →
Repositories → Infrastructure. - Infrastructure imports nothing from
Domain, Services, Repositories or UI. - Shared imports from no other
application layer. - UI does not import repositories or infrastructure
directly. - Services do not import infrastructure directly.

Use a real parser or the selected module tooling. Resolve imports to
canonical file paths, map paths to layers and inspect the transitive
dependency graph.

Cover the mechanisms actually used: - Static imports. - Side-effect
imports. - Re-exports. - Literal dynamic imports. - Non-literal dynamic
imports (must be explicitly reviewed/allow-listed or fail). -
`importScripts()` if used. - HTML script tags. - Workers or CommonJS
only if introduced.

Include deliberately broken fixtures that must fail and valid fixtures
that must pass. Comments and strings containing import-like text must
not cause false failures. Document or prohibit shared-global
dependencies that bypass imports.

## 5. Open decisions and implementation gates

  -----------------------------------------------------------------------
  Decision                            Current status
  ----------------------------------- -----------------------------------
  Import semantics                    Resolved: replace-only, explicit
                                      confirmation, atomic restore

  Backup coverage                     Resolved: all four stores

  Crop-to-plot relationship           Resolved for v1: represented
                                      through records

  JavaScript module system            Resolved: native ES modules

  Initial browser test targets        Current stable Chrome on Android
                                      and desktop

  Dependent-record deletion           Open; decide before implementing
                                      deletion of a site/plot/crop with
                                      dependants

  Persistent storage and quota        Must be implemented defensively and
                                      verified

  Backup reminders                    Not in initial implementation
                                      unless separately approved

  Backup migration policy             Revisit when a later backup format
                                      version exists

  Test framework                      Choose lightweight development
                                      tooling; no test framework is
                                      shipped in the PWA runtime
  -----------------------------------------------------------------------

## 6. Release acceptance gate

FieldLog v1 is not ready for release until: 1. Every required product
acceptance test in section 3 passes. 2. Foundational tests in section 4
pass. 3. Import failure tests prove the complete workspace remains
unchanged. 4. Offline tests pass after successful initial caching. 5.
The target Android phone and desktop/laptop verification is completed.
6. Known limitations and backup risks are documented. 7. No excluded v1
feature has been introduced. 8. Evidence of test execution is recorded.

## 7. Oracle Core eligibility

A component is only a candidate for Oracle Core when: - Its tests pass,
including failure paths. - It has been used by FieldLog without
product-specific workarounds. - Its generic tests contain no
agricultural concepts. - Relevant Android and desktop verification is
complete. - Its interface and limitations are documented.

Passing tests does not automatically mean a component must be extracted.
